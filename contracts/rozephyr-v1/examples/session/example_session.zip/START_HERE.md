# Начало занятия
1. Прочитайте regulation.md целиком.
2. Прочитайте activity.md и context.json.
3. Проведите занятие, сформируйте report.json или ZIP с report.json.
